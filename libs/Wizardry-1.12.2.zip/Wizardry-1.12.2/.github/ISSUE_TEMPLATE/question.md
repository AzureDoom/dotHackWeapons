---
name: Question
about: Ask a question about the mod or the code
title: "[Give a brief, relevant title here]"
labels: question
assignees: ''

---

Please read the [guide for contributing](https://github.com/Electroblob77/Wizardry/blob/1.12.2/guide_for_contributing.md) before posting.

Minecraft version: 1.12.2 [change as necessary]  
Wizardry version: 4.2.2 [change as necessary]

Question details: [explain your question here]

Other mods involved: [if this question involves other mods, list them here]
