# Credits

Electroblob's Wizardry  
Version 4.2.3  
For Minecraft 1.12.2

Designed, coded and textured by Electroblob

Thanks to Minecraft Forge and MCP, without which this mod would not have been possible.

Thanks also to the Minecraft modding community, which always has an answer to my modding problems!

In addition, I'd like to thank the following individuals for their contributions to the mod:

#### Code

- Corail31
- 12foo
- Shadows-of-Fire
- HellFirePvP
- Tora-B
- Avatair
- Aeronica

#### Translations

- Spanish and Mexican Spanish: MadWrist 
- Russian: VilagVil, kellixon 
- French: Hahdrim 
- Brazilian Portuguese: lorrampi 
- Chinese: ZHENGLOC, dragon-evol 
- Korean: shejery, rewi_wire 
- Polish: Trozuu

Lightning ray sound effect from OhhWowProductions
